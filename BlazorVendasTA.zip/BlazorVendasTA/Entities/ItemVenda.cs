﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace BlazorVendasTB.Entities
{
    [Table("tbItemVenda")]
    [PrimaryKey(nameof(ProdutoId), nameof(PedidoId))]
    public class ItemVenda
    {
        public int ProdutoId { get; set; }
        public Produto Produto { get; set; }
        public int PedidoId { get; set; }
        public Pedido Pedido { get; set; }
        public int QuantidadeProduto { get; set; }
        public double PrecoUnitario {  get; set; }
    }
}

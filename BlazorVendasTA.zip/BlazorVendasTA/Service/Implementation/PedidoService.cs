﻿using BlazorVendasTB.Data.Context;
using BlazorVendasTB.Entities;
using BlazorVendasTB.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace BlazorVendasTB.Service.Implementation
{
    public class PedidoService:IPedidoService
    {
        private readonly SQLServerContext _context;

        public PedidoService(SQLServerContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Pedido>> ListarVendaAsync()
        {
            return await _context.Pedidos.ToListAsync();
        }

        public async Task RegistraVendaAsync(Pedido pedido)
        {
            _context.Pedidos.Add(pedido);
            await _context.SaveChangesAsync();
        }
    }
}

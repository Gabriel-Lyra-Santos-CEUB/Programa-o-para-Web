﻿using BlazorVendasTB.Data.Context;
using BlazorVendasTB.Entities;
using BlazorVendasTB.Service.Interface;

namespace BlazorVendasTB.Service.Implementation
{
    public class ItemVendaService:IItemVendaService
    {
        private readonly SQLServerContext _context;

        public ItemVendaService(SQLServerContext context)
        {
            _context = context;
        }

        public async Task ExcluirItemAsync(int id)
        {
            //var itemVenda = await _context.ItensVenda.FindAsync(id);
            //if (itemVenda != null)
            //{
            //    _context.ItensVenda.Remove(itemVenda);
            //    await _context.SaveChangesAsync();
            //}

        }

        public async Task InserirItemAsync(ItemVenda itemVenda)
        {
            //_context.ItensVenda.Add(itemVenda);
            //await _context.SaveChangesAsync();
        }
    }
}

﻿using BlazorVendasTB.Entities;

namespace BlazorVendasTB.Service.Interface
{
    public interface IPedidoService
    {
        Task RegistraVendaAsync(Pedido pedido);
        Task<IEnumerable<Pedido>> ListarVendaAsync();

    }
}

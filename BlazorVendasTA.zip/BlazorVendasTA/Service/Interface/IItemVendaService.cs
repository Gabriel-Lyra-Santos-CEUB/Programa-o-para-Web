﻿using BlazorVendasTB.Entities;

namespace BlazorVendasTB.Service.Interface
{
    public interface IItemVendaService
    {
        Task InserirItemAsync(ItemVenda itemVenda);
        Task ExcluirItemAsync(int id);
    }
}
